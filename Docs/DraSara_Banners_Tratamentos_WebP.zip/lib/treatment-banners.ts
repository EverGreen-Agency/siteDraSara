export const treatmentBanners = {
  "facetas-de-resina": {
    label: "Facetas de Resina e Lentes em Resina",
    desktop: "/images/treatments/facetas-de-resina/hero-desktop.webp",
    mobile: "/images/treatments/facetas-de-resina/hero-mobile.webp",
  },
  "lentes-de-contato-dental": {
    label: "Lentes de Contato Dental e Facetas de Porcelana",
    desktop: "/images/treatments/lentes-de-contato-dental/hero-desktop.webp",
    mobile: "/images/treatments/lentes-de-contato-dental/hero-mobile.webp",
  },
  "clareamento-dental": {
    label: "Clareamento Dental",
    desktop: "/images/treatments/clareamento-dental/hero-desktop.webp",
    mobile: "/images/treatments/clareamento-dental/hero-mobile.webp",
  },
  "fechamento-de-diastemas": {
    label: "Fechamento de Diastemas",
    desktop: "/images/treatments/fechamento-de-diastemas/hero-desktop.webp",
    mobile: "/images/treatments/fechamento-de-diastemas/hero-mobile.webp",
  },
  "implantes-dentarios": {
    label: "Implantes Dentários",
    desktop: "/images/treatments/implantes-dentarios/hero-desktop.webp",
    mobile: "/images/treatments/implantes-dentarios/hero-mobile.webp",
  },
  "protese-protocolo": {
    label: "Prótese Protocolo",
    desktop: "/images/treatments/protese-protocolo/hero-desktop.webp",
    mobile: "/images/treatments/protese-protocolo/hero-mobile.webp",
  },
  "enxerto-osseo-dentario": {
    label: "Enxerto Ósseo para Implantes",
    desktop: "/images/treatments/enxerto-osseo-dentario/hero-desktop.webp",
    mobile: "/images/treatments/enxerto-osseo-dentario/hero-mobile.webp",
  },
  "proteses-dentarias": {
    label: "Próteses Dentárias",
    desktop: "/images/treatments/proteses-dentarias/hero-desktop.webp",
    mobile: "/images/treatments/proteses-dentarias/hero-mobile.webp",
  },
  "inlays-onlays": {
    label: "Inlays e Onlays / Restaurações Indiretas",
    desktop: "/images/treatments/inlays-onlays/hero-desktop.webp",
    mobile: "/images/treatments/inlays-onlays/hero-mobile.webp",
  },
  "reabilitacao-oral": {
    label: "Reabilitação Oral",
    desktop: "/images/treatments/reabilitacao-oral/hero-desktop.webp",
    mobile: "/images/treatments/reabilitacao-oral/hero-mobile.webp",
  },
  "ortodontia": {
    label: "Ortodontia / Aparelhos e Alinhadores",
    desktop: "/images/treatments/ortodontia/hero-desktop.webp",
    mobile: "/images/treatments/ortodontia/hero-mobile.webp",
  },
  "invisalign": {
    label: "Invisalign / Alinhadores Transparentes",
    desktop: "/images/treatments/invisalign/hero-desktop.webp",
    mobile: "/images/treatments/invisalign/hero-mobile.webp",
  },
  "manutencao-odontologica": {
    label: "Manutenção e Acompanhamento Odontológico",
    desktop: "/images/treatments/manutencao-odontologica/hero-desktop.webp",
    mobile: "/images/treatments/manutencao-odontologica/hero-mobile.webp",
  },
  "limpeza-dental": {
    label: "Limpeza Dental / Profilaxia",
    desktop: "/images/treatments/limpeza-dental/hero-desktop.webp",
    mobile: "/images/treatments/limpeza-dental/hero-mobile.webp",
  },
  "periodontia": {
    label: "Periodontia / Tratamento de Gengiva",
    desktop: "/images/treatments/periodontia/hero-desktop.webp",
    mobile: "/images/treatments/periodontia/hero-mobile.webp",
  },
  "cirurgia-gengival": {
    label: "Gengivoplastia e Cirurgia Gengival",
    desktop: "/images/treatments/cirurgia-gengival/hero-desktop.webp",
    mobile: "/images/treatments/cirurgia-gengival/hero-mobile.webp",
  },
  "tratamento-de-canal": {
    label: "Tratamento de Canal / Endodontia",
    desktop: "/images/treatments/tratamento-de-canal/hero-desktop.webp",
    mobile: "/images/treatments/tratamento-de-canal/hero-mobile.webp",
  },
  "extracao-de-siso": {
    label: "Extração de Siso",
    desktop: "/images/treatments/extracao-de-siso/hero-desktop.webp",
    mobile: "/images/treatments/extracao-de-siso/hero-mobile.webp",
  },
  "bruxismo": {
    label: "Bruxismo, DTM e Dor Orofacial",
    desktop: "/images/treatments/bruxismo/hero-desktop.webp",
    mobile: "/images/treatments/bruxismo/hero-mobile.webp",
  },
  "bichectomia": {
    label: "Bichectomia",
    desktop: "/images/treatments/bichectomia/hero-desktop.webp",
    mobile: "/images/treatments/bichectomia/hero-mobile.webp",
  },
  "harmonizacao-facial": {
    label: "Harmonização Facial",
    desktop: "/images/treatments/harmonizacao-facial/hero-desktop.webp",
    mobile: "/images/treatments/harmonizacao-facial/hero-mobile.webp",
  },
  "preenchimento-facial": {
    label: "Preenchimento Facial",
    desktop: "/images/treatments/preenchimento-facial/hero-desktop.webp",
    mobile: "/images/treatments/preenchimento-facial/hero-mobile.webp",
  },
  "preenchimento-labial": {
    label: "Preenchimento Labial",
    desktop: "/images/treatments/preenchimento-labial/hero-desktop.webp",
    mobile: "/images/treatments/preenchimento-labial/hero-mobile.webp",
  },
  "botox": {
    label: "Botox / Toxina Botulínica e Linhas de Expressão",
    desktop: "/images/treatments/botox/hero-desktop.webp",
    mobile: "/images/treatments/botox/hero-mobile.webp",
  },
  "bioestimuladores-de-colageno": {
    label: "Bioestimuladores de Colágeno",
    desktop: "/images/treatments/bioestimuladores-de-colageno/hero-desktop.webp",
    mobile: "/images/treatments/bioestimuladores-de-colageno/hero-mobile.webp",
  },
  "perfiloplastia": {
    label: "Perfiloplastia",
    desktop: "/images/treatments/perfiloplastia/hero-desktop.webp",
    mobile: "/images/treatments/perfiloplastia/hero-mobile.webp",
  },
} as const;

export type TreatmentBannerSlug = keyof typeof treatmentBanners;